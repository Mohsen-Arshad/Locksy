# Locksy v1.2.2

- Set English as the default language on the first launch of v1.2.2. A one-time migration also resets an existing Persian preference to English for this upgrade; language choices made afterward are retained.
- Rebuilt the Theme row as a custom animated sun/moon control using Locksy's own vector icons, gradient thumb, purple track, and a larger tappable settings row. It is not a native MAUI `Switch`.
- Replaced newer Unicode isolate markers with classic Unicode RTL/LTR embeddings in display-only text formatting to improve mixed Persian/English ordering in About, task titles, and the Android lock-screen wallpaper. Stored task text remains unchanged.
- Explicitly apply paragraph direction and justified wrapping to long modal descriptions and task titles.
- Queue a wallpaper refresh during the language-default migration when a previously Persian installation has Auto Update enabled. Language changes also queue a refresh when Auto Update is enabled.
- Bump the app to version 1.2.2 (Android versionCode 12).

Build with Visual Studio/.NET MAUI and test on a physical Android device before release. After installing, press **Apply wallpaper** once if Auto Update is disabled so Android regenerates the existing wallpaper bitmap.
